// IMPORT NODEJS MODULES
var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
var socket = require('socket.io');
var execFile = require('child_process').execFile;

//CREATE THE EXPRESS APP FOR THE WEB SERVER
var app = express();
app.set('env', 'development');

//SOME VIEWS CONFIGURATION
app.set('views', path.join(__dirname, 'public'));
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');

//SOME MIDDLEWARE CONFIGURATION
var cors = require('cors');
app.use(cors({
    credentials: true, 
    origin: true, 
    preflightContinue: true, 
    methods: 'GET,POST',
    allowedHeaders: 'Content-Type,Data-Type',
}));

app.use(express.static(path.join(__dirname, 'public')));

//RENDER OF THE INDEX PAGE 
app.get ('/',(req,res) =>{
    res.render('index', {});
});

//START SERVER ON PORT 3000
var debug = require('debug')('WebAPI');
app.set('port', process.env.PORT || 3000);
var server = app.listen(app.get('port'), function() {
  debug('Express server listening on port ' + server.address().port);
});
console.log('Application available at port: ' + app.get('port'));


//SOCKET SETUP
var io = socket(server);

//ON CONNECTION DO THIS
io.on('connection',function(socket){

    //CONSOLE OUTPUT TO CONFIRM CONNECTION
    console.log('A player has connected to ArkanoPi.');

    //ON 'COMMAND' DO THIS
    socket.on('command', function(data){
        if(data ==="start"){

            //EXEC THE ARKANOPI EXECUTABLE AS A CHILD PROCESS OF NODE.JS
            child = execFile('./ArkanoPi');
        }
        else{  

            //WRITE DATA TO STANDARD INPUT OF CHILD PROCESS (ARKANO_PI)
            child.stdin.write(data);
        }
        });


});

//EXPORT ALL THE MODULES TO THE APP
module.exports = app;