//CONNECT TO MY RASPI IP ON PORT 3000
var socket = io.connect("http://192.168.0.22:3000");

//GET EVERY BUTTON
var start = document.getElementById("startButton");
    begin = document.getElementById("beginButton"),
    exit = document.getElementById("exitButton"),
    left = document.getElementById("leftButton"),
    pause = document.getElementById("pauseButton"),
    right = document.getElementById("rightButton"),
    next = document.getElementById("nextButton");

//EMIT EVENTS WHEN BUTTON IS CLICKED
    start.addEventListener('click',function(){

        socket.emit('command',"start");

    });


    begin.addEventListener('click',function(){

        socket.emit('command',"z");

    });

    left.addEventListener('click',function(){

        socket.emit('command',"a");
        
       

    });

    right.addEventListener('click',function(){

        socket.emit('command',"l");
        
        

    });

    pause.addEventListener('click',function(){

        socket.emit('command',"p");
        
        
        

    });

    exit.addEventListener('click',function(){

        socket.emit('command',"q");
        
    
    });

    next.addEventListener('click',function(){

        socket.emit('command',"x");
        
        
    
    });


